
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Giovanna
 */
public class ProjetoIndividual {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        Integer operacaoDigitada;
        Integer quantidadePontos = 0;
        String frase = "";
        Integer numeroAleatorio = 0;
        do {
            System.out.println("Olá, o que deseja fazer?"
                    + "\n1 - Calculo Pontos na Carteira \n2 - Multas  \n3 - CNH Suspensa? \n0 - Sair");
            operacaoDigitada = leitor.nextInt();

            if (operacaoDigitada >= 1 && operacaoDigitada <= 4) {
                switch (operacaoDigitada) {

                    case 1 -> {
                        System.out.println("Velocidade da Via");
                        Double velocidadeDigitada = leitor.nextDouble();
                        if (velocidadeDigitada < 0) {
                            frase = "Valor invalido";
                        } else {

                            for (int i = 1; i <= 10; i++) {
                                numeroAleatorio = ThreadLocalRandom.current().nextInt(30, 250);

                                if (numeroAleatorio > velocidadeDigitada) {
                                    quantidadePontos += 1;
                                }

                                System.out.println("Velocidade na " + i + "º: " + numeroAleatorio + " km/h");
                            }
                            System.out.println("to aqui" + quantidadePontos);
                        }
                    }
                    case 2 -> {

                        if (quantidadePontos <= 0) {
                            
                            frase = "Você não possui multas";
                            
                        } else {
                            
                            frase = "Você possui " + quantidadePontos + " multas";
                        }

                    }
                    case 3 -> {
                        Integer pontos = quantidadePontos * 5;
                        if(pontos < 20){
                            
                            frase = "Sua carteira não foi suspeita";
                            
                        }else{
                            
                            frase = "Sua carteira foi suspensa";
                            
                        }
                    }

                }
                System.out.println(frase);
            } else if (operacaoDigitada < 0 || operacaoDigitada > 3) {

                System.out.println("Opção invalida, tente novamente");

            } else {

                System.out.println("Até logo");
            }

        } while (operacaoDigitada != 0);

    }
}
